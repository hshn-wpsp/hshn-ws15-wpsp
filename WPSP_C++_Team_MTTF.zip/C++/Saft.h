#pragma once

enum class Saft
{
	Banane, Kirsche, Birne, Multi
};